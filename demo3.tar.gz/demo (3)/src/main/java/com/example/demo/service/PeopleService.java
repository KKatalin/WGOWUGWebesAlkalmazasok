package com.example.demo.service;

public interface PeopleService {
void savePeople(People people);
}
