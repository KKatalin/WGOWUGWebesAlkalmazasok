package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PeopleController {
	
	@PostMapping(path = "/people", consumes = "application/json")
	public void savePeople(@Valid @RequestBody PeopleDto peopleDto) {
		System.out.println(peopleDto);
		
	}
	

}
