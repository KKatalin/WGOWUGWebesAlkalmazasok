package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service //megannotáljuk a service implementációval
public class PeopleServiceimpl implements PeopleService {
public void savePeople(People people) {
	
}
}
