package com.example.demo.repository;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class People {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private Long age;
	@Column(length=20)
	private String name;
}

/*
repository csomagba:
public interface PeopleRepository extends CrudRepository<people, long> {

}

*/