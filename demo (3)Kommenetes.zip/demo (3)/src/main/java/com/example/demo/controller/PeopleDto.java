package com.example.demo.controller;
// amikor beküldenek nekünk egy új embert akkor milyen adata lesz.Ahhoz a kéréshez mi kell. Nem kell ID, d adatcserélésnél kell ID
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.example.demo.service.People;
import com.sun.istack.NotNull;

public class PeopleDto {
	private Long id; //vagy megköveteljük, vagy nem. 
	@NotBlank // nem lehet üres, kényszer
	@Size(min = 3) // új függőséget vettünk fel a pom.xml-be, min 3 karakterű név legyen
	private String name;
	@NotNull // a kor nem lehet nulla
	@Min(1) //legalább 1 éves mindenki
	private Integer age;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	//mivel a dto adattagjai privát, gettert és settert generáltunk hozzá, h a controller lássa
	public People toPeople() { //átalakítja a megfelelő elemet, meghívja a metódust
		People people = new People(); //a dto ami a felső rétegbe van ismeri az alatta lévő rétegnek a valuját
		people.setId(getId());
		people.setAge(getAge());
		people.setName(getName());
		return people; //saját maga állapotából létrehoz egy típust és besetteli az adattagot
		// megkéri a szervízt hogy mentse el ha akarja a következő elemet, entitást ami kívülről ugyan de egy belső reprezentáci forgatj át egy külső entitással
	}
	//tostringet is generálunk

	@Override
	public String toString() {
		return "PeopleDto [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
}
//a spring látja hogy van egy validáció ezen ezért a kérés request bodíjában lévő Json, megpróbálja a JSon stringet átkonvertálni peopledto-vá
//ha nem sikerül a szerver visszaküldi a kliensnek hogy ez rossz kérés volt
// ha sikerül megnézi hogy ezen a people dto-n vannak e kényszerek (vannak)
//ha minden sikeres, akkor beengedi a kérést
