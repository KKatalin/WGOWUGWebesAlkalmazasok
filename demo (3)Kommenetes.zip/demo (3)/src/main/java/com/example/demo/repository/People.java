package com.example.demo.repository;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity //magába vonja hogy kell egy id, megjelöli h ezt az osztályt h az adatbázis táblájában ...ba kell vonni,
// ha létrhoztunk egy új pldányt, akkornekünk a táblába új sor fog létrejönni
// ebből az osztálynévből generál egy táblanevet
public class People {
	@Id // azt bioztosítja nekünk, hogy bármi adatbázis kezelő van a háttérbe , egy új save metódus hívódik akk a soron következő értéket kapja
	@GeneratedValue(strategy = GenerationType.AUTO) //autómatikusan implementálja az id-t
	private Long id; //long típusú adattag aminek van egy id annotációja
	private Long age; //ezek autómatikusan mezője lesznek az új táblának
	@Column(length=20)
	private String name;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getAge() {
		return age;
	}
	public void setAge(Long age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}

