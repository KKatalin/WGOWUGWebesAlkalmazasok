package com.example.demo.service;
//interfész
//implementálja az interfészt peopleserviceimpl névvel, annak a metódusát is
public interface PeopleService {
void savePeople(People people);
}
