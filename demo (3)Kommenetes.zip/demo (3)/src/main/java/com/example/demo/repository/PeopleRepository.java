package com.example.demo.repository;

import org.springframework.data.repository.CrudRepository;

//interfész
// 2 tipusparamétere van, az első az indexnek a típusa a 2. az a people osztály, ami el van látva entitivel
// crud repo a save all, find all, count, save, delet metódusokat adja
//futásidőbe beimplementálja az interfészt 
public interface PeopleRepository extends CrudRepository<People,Long>  {

}
