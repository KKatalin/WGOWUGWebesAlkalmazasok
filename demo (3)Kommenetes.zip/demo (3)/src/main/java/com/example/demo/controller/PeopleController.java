package com.example.demo.controller;

import javax.validation.Valid;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PeopleController {
	
	@PostMapping(path = "/people", consumes = "application/json") 
	//post kérésre fog válaszolni, a post/people-ra jön egy kérés, az útvonalat is megadjuk, és hogy jsont használunk
	public void savePeople(@Valid @RequestBody PeopleDto peopleDto) {
		System.out.println(peopleDto); //mivel a dto adattagjai privát, gettert és settert generáltunk hozzá
		
	}
	

}
// ha megvan a dto. pl ha ennek a kérésnek, hogy lementsünk 1 új embert, erre az infóra szükségünk van
//ezt belepakoltuk egy dto-ba
// van egy controller osztályunk, van 1 metódus belül (savePeople), és meg van jelölve @PostMapping, van egy útvonal
